# coding: utf8
import os 
import json
import shutil

# try something like
def index(): 
	response.active = "index"
	response.title = "ACES-ACM IIT Delhi"
	return locals()

def teamcurrent():
	response.active = "team"
	response.title = "Team 2016-17 | ACES-ACM Team 2015-2016"
	return locals()

def team2015():
	response.active = "team"
	response.title = "Team 2015-16 | ACES-ACM Team 2015-2016"
	return locals()

def team2014():
	response.active = "team"
	response.title = "Team 2014-15 | ACES-ACM Team 2014-2015"
	return locals()

def team2013():
	response.active = "team"
	response.title = "Team 2013-14 | ACES-ACM Team 2013-2014"
	return locals()

def ACM():
	response.active = "about"
	response.title = "About ACM | ACES-ACM IIT Delhi"
	return locals()


def ACES():
	response.active = "about"
	response.title = "About ACES | ACES-ACM IIT Delhi"
	return locals()

def APC():
	response.title = "About APC | ACES-ACM IIT Delhi"
	return locals()

def about():
	response.active = "about"
	response.title = "About Us | ACES-ACM IIT Delhi"
	return locals()

def events2015():
	response.active = "events"
	response.title = " Events 2015-16 | ACES-ACM IIT Delhi"
	return locals()

def events2014():
	response.active = "events"
	response.title = " Events 2014-15 | ACES-ACM IIT Delhi"
	return locals()

def events2013():
	response.active = "events"
	response.title = " Events 2013-14 | ACES-ACM IIT Delhi"
	return locals()

def gallery():
	response.active = "gallery"
	response.title = " Picture Gallery | ACES-ACM IIT Delhi"
	return locals()

def contact():
	response.active = "contact"
	response.title = " Contact Us | ACES-ACM IIT Delhi"
	return locals()

def imedita():
	response.title = " IBNC | ACES-ACM IIT Delhi"
	return locals()

def event_template():
	response.title = "Yahoo! HackU 2013 | ACES-ACM IIT Delhi"
	return locals()

def frosh():
	response.title = "Frosh Welcome 2014 | ACES ACM IIT Delhi"
	return locals()

def freshers():
	response.title = "Fresher's Welcome 2014 | ACES ACM IIT Delhi"
	return locals()

def zerohour():
	response.title = "Zero Hour 2014 | ACES ACM IIT Delhi"
	return locals()

def cs():
	response.title = "Counter Strike | ACES ACM IIT Delhi"
	return locals()

def kabaddi():
	response.title = "Kabaddi | ACES ACM IIT Delhi"
	return locals()

def treasurehunt():
	response.title = "Treasure Hunt | ACES ACM IIT Delhi"
	return locals()

def workshops():
	response.title = "Workshops | ACES ACM IIT Delhi"
	return locals()


def moviescreening():
	response.title = "Movies@Zero Hour | ACES ACM IIT Delhi"
	return locals()

def doubletrouble():
	response.title = "Double Trouble | ACES ACM IIT Delhi"
	return locals()

def codingclub():
	response.title = "Coding Club Events | ACES ACM IIT Delhi"
	return locals()

def number():
	response.title = "Bridge, Number Games and Chess | ACES ACM IIT Delhi"
	return locals()

def Nov2014():
	response.title = "November 2014 | ACES ACM IIT Delhi"
	return locals()

def tryst():
	response.title = "Tryst 2015 | ACES ACM IIT DELHI"
	return locals()

def examArchive(): 
	import os
	form = SQLFORM(db.questionpaper, labels = {'code':'Course Code', 'name':'Course Name', 'exam':'Exam Type' , 'examyear':'Year', 'fileurl':'Choose File'})
	statusform=''
	if form.process().accepted:
		statusform='Your Question Paper has Been Submitted, and will be added to database once verified by Admin '
		response.flash = 'Your Question Paper has Been Submitted, and will be added to database once verified by Admin '
	elif form.errors:
		statusform='The Form has errors, Please Complete the form in all respects'
		response.flash = 'The Form has errors, Please Complete the form in all respects'    
	try:
		url = "/".join(request.args[:])
		#url = "/".join(request.raw_args[:])
		url= url.replace("%20", " ")
		#print url
		#remString = '/'.join(request.env.request_uri.split("/")[3:])
	except:
		return dict(files=[f for f in os.listdir("/home/attic/web2py/applications/acesacm/QuestionPapers/")],form=form,statusform=statusform)

	#print "/home/aman/Desktop/Web2py/web2py/applications/mymoodle/static/"+url
	if(os.path.isfile("/home/attic/web2py/applications/acesacm/QuestionPapers/"+url)):
		response.stream(os.path.join("/home/attic/web2py/applications/acesacm/QuestionPapers/"+url))
	else:
#        names = [f.replace("_"," ") for f in os.listdir("/home/attic/web2py/applications/acesacm/QuestionPapers/"+url)]
		names = os.listdir("/home/attic/web2py/applications/acesacm/QuestionPapers/"+url)
		names.sort()
		return dict(files=names,form=form,statusform=statusform)

def privacy():
	return locals()

def toc():
	return locals()

def deploycampusbot():
	return locals()

def download():
	import os
	import gluon.contenttype
	filename=request.args[0]
	response.headers['Content-Type']=gluon.contenttype.contenttype(filename)
	pathfilename=os.path.join(request.folder,'output/', filename)
	return open(pathfilename, 'rb').read()

def complaints():
	import csv	
	return locals()

def get_papers(entry):
	baaproot = "/home/attic/web2py/applications/acesacm/QuestionPapers2"
	output_home_dir = "/home/attic/web2py/applications/acesacm/output"
	output_dir = output_home_dir + "/" + entry.upper()
	if not os.path.exists(output_dir):
		os.makedirs(output_dir)
	with open("/home/attic/web2py/applications/acesacm/Data Collection/data_base.json") as datafile :
		data = json.load(datafile)

	courses  = data[entry.upper()]['courses']
	for course in courses:
		dept = course[:3]
		if(dept=='COL'):
			for data_base_cname in sorted(os.listdir(baaproot+"/COL")):
				if (data_base_cname==course):
					shutil.copytree(baaproot+"/COL/" + course, output_dir + "/" + course)

	shutil.make_archive(output_home_dir + "/" + entry, 'zip', output_dir)
	shutil.rmtree(output_dir)

@request.restful()
def api():
	response.view = 'generic.json'
	def GET (entry):
		get_papers(entry.upper())
		return dict(url = "www.cse.iitd.ernet.in/aces-acm/download/" + entry.upper() + ".zip")
	def POST(action, **vars):
		response.view = 'generic.json'
		if (action == "postcomplaint"):
			subject= vars["Subject"]
			desc = vars["Description"]
			people = vars["People In-Charge"]
			name = vars["Name"]
			entry = vars["Entry Number"]
			import csv
			with open('/home/attic/web2py/applications/acesacm/complaints.csv', 'a') as csvfile:
				complaints = csv.writer(csvfile, delimiter=' ',quotechar='|', quoting=csv.QUOTE_MINIMAL)
				complaints.writerow([subject,desc,people,name,entry])
			return dict(status ="Complaint Logged")
		else:
			raise HTTP(400)
	return locals()